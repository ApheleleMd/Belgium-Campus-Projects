CREATE OR ALTER VIEW vw_MembershipStatus AS
WITH StatusCheck AS (
    SELECT 
        MemberID,
        MembershipType,
        StartDate,
        EndDate,
        CASE 
            WHEN GETDATE() BETWEEN StartDate AND EndDate THEN 'Active'
            ELSE 'Expired'
        END AS Status
    FROM Membership
)
SELECT 
    CONCAT(m.FirstName, ' ', m.LastName) AS FullName,
    sc.MembershipType,
    sc.StartDate,
    sc.EndDate,
    sc.Status
FROM StatusCheck sc
JOIN Member m ON m.MemberID = sc.MemberID;