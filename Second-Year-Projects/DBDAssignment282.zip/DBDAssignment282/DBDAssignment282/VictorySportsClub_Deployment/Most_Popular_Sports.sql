SELECT 
    s.SportName,
    COUNT(*) AS RegistrationCount
FROM MemberSport ms
JOIN Sport s ON ms.SportID = s.SportID
GROUP BY s.SportName
ORDER BY RegistrationCount DESC;
