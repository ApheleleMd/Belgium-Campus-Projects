SELECT CONCAT(m.FirstName, ' ', m.LastName) AS FullName
FROM Member m
WHERE NOT EXISTS (
    SELECT 1 FROM Payment p WHERE p.MemberID = m.MemberID
);