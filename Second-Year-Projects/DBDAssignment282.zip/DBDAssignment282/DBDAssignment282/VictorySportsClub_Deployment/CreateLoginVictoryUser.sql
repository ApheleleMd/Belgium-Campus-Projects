
-- Create SQL Server login (server-level)
CREATE LOGIN VictoryUser WITH PASSWORD = 'Victory123!';

-- Use the target database
USE VictorySportsDB;
GO

-- Create database user
CREATE USER VictoryUser FOR LOGIN VictoryUser;

-- Grant access roles
EXEC sp_addrolemember 'db_datareader', 'VictoryUser';
EXEC sp_addrolemember 'db_datawriter', 'VictoryUser';
