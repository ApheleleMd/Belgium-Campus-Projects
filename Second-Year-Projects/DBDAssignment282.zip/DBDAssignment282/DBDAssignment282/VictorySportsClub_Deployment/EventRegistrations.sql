CREATE OR ALTER VIEW vw_EventRegistrations AS
WITH EventDetails AS (
    SELECT 
        e.EventID,
        e.EventName,
        e.EventDate,
        s.SportName,
        e.Location
    FROM Event e
    JOIN Sport s ON e.SportID = s.SportID
)
SELECT 
    CONCAT(m.FirstName, ' ', m.LastName) AS FullName,
    ed.EventName,
    ed.SportName,
    er.RegistrationDate,
    ed.EventDate,
    ed.Location
FROM EventRegistration er
JOIN Member m ON er.MemberID = m.MemberID
JOIN EventDetails ed ON er.EventID = ed.EventID;
