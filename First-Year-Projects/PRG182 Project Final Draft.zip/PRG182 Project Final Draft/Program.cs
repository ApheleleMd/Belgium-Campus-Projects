﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Final_Draft_Project_Milestone
{
    internal class Program
    {
        // Class to represent an applicant
        class Applicant
        {
            public string Name { get; set; }
            public int Age { get; set; }
            public int HighScoreRank { get; set; }
            public DateTime StartDate { get; set; }
            public int PizzasConsumed { get; set; }
            public int BowlingHighScore { get; set; }
            public bool Employed { get; set; }
            public string SlushPuppyFlavor { get; set; }
            public int SlushPuppiesConsumed { get; set; }
        }
        class RetroSliceApplication
        { 
            public double CalculateAveragePizzasConsumed(List<Applicant> applicants)
            {
                int totalPizzas = 0;
                int totalVisits = 0;

                foreach (Applicant applicant in applicants)
                {
                    totalPizzas += applicant.PizzasConsumed;
                    totalVisits++;
                }

                double averagePizzas = (double)totalPizzas / totalVisits;
                return averagePizzas;
            }

            public string GetAgeExtremes(List<Applicant> applicants)
            {
                int youngestAge = int.MaxValue;
                int oldestAge = int.MinValue;

                foreach (Applicant applicant in applicants)
                {
                    if (applicant.Age < youngestAge)
                    {
                        youngestAge = applicant.Age;
                    }

                    if (applicant.Age > oldestAge)
                    {
                        oldestAge = applicant.Age;
                    }

                }
                return $"Youngest Applicant: {youngestAge}\nOldest Applicant: {oldestAge}";
            }

            public bool CheckLongTermLoyalty(Applicant applicant)
            {
                DateTime currentDate = DateTime.Now;
                TimeSpan loyaltyDuration = currentDate - applicant.StartDate;

                if (loyaltyDuration.TotalDays >= 3650) // 10 years in days
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            public void ShowLoadingAnimation()
            {
                Console.WriteLine("Loading...");
                Thread.Sleep(2000); // Simulate loading time
                Console.WriteLine("Loading complete! (100%)");
            }
        }

        // Enum to represent menu options
        enum Menu
        {
            CaptureDetails = 1,
            CheckQualification,
            ShowStats,
            CalculateAveragePizzasConsumed,
            GetAgeExtremes,
            CheckLongTermLoyalty,       
            Exit
        }

        static void Main(string[] args)
        {
            List<Applicant> allApplicants = new List<Applicant>();
            List<Applicant> qualifiedApplicants = new List<Applicant>();
            List<Applicant> deniedApplicants = new List<Applicant>();

            RetroSliceApplication app = new RetroSliceApplication();

            app.ShowLoadingAnimation();


            bool repeat = true;
           

            do
            {
                Console.Clear();
                Console.WriteLine("RetroSlice");
                Console.WriteLine("1 : Capture applicant's details");
                Console.WriteLine("2 : Check game token credit qualification");
                Console.WriteLine("3 : Show qualification status");
                Console.WriteLine("4 : Calculate average pizzas consumed");
                Console.WriteLine("5 : Get age extremes");
                Console.WriteLine("6 : Check Long-Term loyalty");
                Console.WriteLine("7 : Exit");
                Console.WriteLine("---------------------------------------");
                Console.Write("Enter option: ");
                int option = int.Parse(Console.ReadLine());
                Console.WriteLine("---------------------------------------");

                switch ((Menu)option)
                {
                    case Menu.CaptureDetails:
                        CaptureDetails(allApplicants);
                        break;
                    case Menu.CheckQualification:
                        CheckQualification(allApplicants, qualifiedApplicants, deniedApplicants);
                        break;
                    case Menu.ShowStats:
                        DisplayStats(qualifiedApplicants, deniedApplicants);
                        break;
                    case Menu.CalculateAveragePizzasConsumed:
                        double averagePizzas = app.CalculateAveragePizzasConsumed(allApplicants);
                        Console.WriteLine($"Average Pizzas Consumed per First Visit: {averagePizzas}");
                        Console.ReadKey();
                        break;
                    case Menu.GetAgeExtremes:
                        string ageExtremes = app.GetAgeExtremes(allApplicants);
                        Console.WriteLine(ageExtremes);
                        Console.ReadKey();
                        break;
                    case Menu.CheckLongTermLoyalty:

                        foreach (Applicant applicant in allApplicants)
                        {
                            if (app.CheckLongTermLoyalty(applicant))
                            {
                                Console.WriteLine($"{applicant.Name} qualifies for the long-term loyalty award.");
                            }
                            else
                            {
                                Console.WriteLine($"{applicant.Name} does not qualify for the long-term loyalty award. ");
                            }

                        }
                        Console.ReadKey();
                        break;
                    case Menu.Exit:
                        repeat = false;
                        break;
                    default:
                        Console.WriteLine("Enter a valid option");
                        break;
                }

            } while (repeat);

            
        }

        // Method to capture applicant details
        static void CaptureDetails(List<Applicant> allApplicants)
        {
            Console.Write("Enter Name: ");
            string name = Console.ReadLine();

            Console.Write("Enter Age: ");
            int age = int.Parse(Console.ReadLine());

            Console.Write("Enter High Score Rank: ");
            int highScoreRank = int.Parse(Console.ReadLine());

            Console.Write("Enter Starting Date as a Loyal Customer (YYYY-MM-DD): ");
            DateTime startDate = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter Number of Pizzas Consumed Since First Visit: ");
            int pizzasConsumed = int.Parse(Console.ReadLine());

            Console.Write("Enter Bowling High Score: ");
            int bowlingHighScore = int.Parse(Console.ReadLine());

            Console.Write("Are you Employed (Yes/No): ");
            bool employed = Console.ReadLine().ToLower() == "yes";

            Console.Write("Enter Slush-Puppy Flavor Preference: ");
            string slushPuppyFlavor = Console.ReadLine();

            Console.Write("Enter Number of Slush-Puppies Consumed Since First Visit: ");
            int slushPuppiesConsumed = int.Parse(Console.ReadLine());

            allApplicants.Add(new Applicant
            {
                Name = name,
                Age = age,
                HighScoreRank = highScoreRank,
                StartDate = startDate,
                PizzasConsumed = pizzasConsumed,
                BowlingHighScore = bowlingHighScore,
                Employed = employed,
                SlushPuppyFlavor = slushPuppyFlavor,
                SlushPuppiesConsumed = slushPuppiesConsumed
            });

            Console.WriteLine("Applicant details captured successfully.");
            Console.WriteLine("---------------------------------------");
            Console.ReadKey();
        }

        // Method to check qualification for game token credit
        static void CheckQualification(List<Applicant> allApplicants, List<Applicant> qualifiedApplicants, List<Applicant> deniedApplicants)
        {
            qualifiedApplicants.Clear();
            deniedApplicants.Clear();

            foreach (var applicant in allApplicants)
            {
                bool qualifies = true;

                if (!applicant.Employed && applicant.Age >= 18)
                {
                    qualifies = false;
                }

                if ((DateTime.Now - applicant.StartDate).TotalDays / 365 < 2)
                {
                    qualifies = false;
                }

                if (applicant.HighScoreRank <= 2000 && applicant.BowlingHighScore <= 1500 && (applicant.HighScoreRank + applicant.BowlingHighScore) / 2 <= 1200)
                {
                    qualifies = false;
                }

                if (applicant.PizzasConsumed / ((DateTime.Now - applicant.StartDate).TotalDays / 30) < 3)
                {
                    qualifies = false;
                }

                if (applicant.SlushPuppyFlavor == "Gooey Gulp Galore" || applicant.SlushPuppiesConsumed / ((DateTime.Now - applicant.StartDate).TotalDays / 30) <= 4)
                {
                    qualifies = false;
                }

                if (qualifies)
                {
                    qualifiedApplicants.Add(applicant);
                }
                else
                {
                    deniedApplicants.Add(applicant);
                }
            }

            Console.WriteLine("Game token credit checks have been performed.");
            Console.WriteLine("---------------------------------------");
            Console.ReadKey();
        }

        // Method to display qualification stats
        static void DisplayStats(List<Applicant> qualifiedApplicants, List<Applicant> deniedApplicants)
        {
            Console.WriteLine("Qualified Applicants:");
            foreach (var applicant in qualifiedApplicants)
            {
                Console.WriteLine(applicant.Name);
            }
            Console.WriteLine($"Number of Applicants Granted Tokens: {qualifiedApplicants.Count}");
            Console.WriteLine("---------------------------------------");

            Console.WriteLine("Denied Applicants:");
            foreach (var applicant in deniedApplicants)
            {
                Console.WriteLine(applicant.Name);
            }
            Console.WriteLine($"Number of Applicants Denied Tokens: {deniedApplicants.Count}");
            Console.WriteLine("---------------------------------------");
            Console.ReadKey();
        }
    }
}